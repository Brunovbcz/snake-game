//Constants
const size = 30
const colorGradient = 1

//Canvas settings
let canvas = document.querySelector('.game-canvas')
let ctx = canvas.getContext('2d')

canvas.width = columns * size
canvas.height = rows * size

//Menus
let gameOverMenu = document.querySelector('.game-over-menu')
let fruitImg = document.querySelector('.fruit-img')

//Buttons
const restartButton = document.querySelector('#restart')
const menuButton = document.querySelector('#menu')

let realcolors = {
    red:     [190, 30, 45],
    blue:    [60, 100, 180],
    green:   [60, 120, 60],
    yellow:  [240, 220, 100],
    orange:  [230, 120, 40],
    purple:  [100, 70, 130],
    black:   [20, 20, 20],
    white:   [245, 245, 245],
    gray:    [110, 110, 110],
    pink:    [230, 150, 170],
}

//Global variables
let speed = 4
let eaten = 0
let record = 0
let color = 'rgb(60, 100, 180)'
let strokeColor = 'gray'

//Canvas Margins
let middleX = canvas.width / 2
let xMargin = Math.floor((canvas.width / size) / 4) * size
let middleY

if ((canvas.height / size) % 2 === 0) { middleY = canvas.height / 2 }
else { middleY = (canvas.height / 2) - size / 2 }

//Unitialized variables
let direction
let currentDirection
let loop

//Bools
let db = false
let shouldGrow = false

//Images
const eyeImage = new Image()
eyeImage.src = 'contents/images/snake/eyes/graphics_00.png' // The snake's eye

const fruitImage = new Image()
fruitImage.src = 'contents/images/fruits/apple.png' // The fruit that the snake will eat
fruitImg.src = fruitImage.src       // The fruit that will be shown in the menu

let randomXPos = () => {
    let maxMultipleX = Math.floor(canvas.width / size)
    let randomMultipleX = Math.floor(Math.random() * (maxMultiple + 1));
    let result = (randomMultipleX * size) - size
    if (result < 0){ result = 0 }
    return result
}

let randomYPos = () => {
    let maxMultipleY = Math.floor(canvas.height / size)
    let randomMultipleY = Math.floor(Math.random() * (maxMultiple + 1));
    let result = (randomMultipleY * size) - size
    if (result < 0){ result = 0 }
    return result
}

let snake = [
    {x: xMargin, y: middleY},
    {x: xMargin + (size), y: middleY},
    {x: xMargin + (size * 2), y: middleY},
    {x: xMargin + (size * 3), y: middleY},
]

let fruit = {x: canvas.width - xMargin, y: middleY}

function updateLayoutVars() {
    canvas.width = columns * size
    canvas.height = rows * size

    middleX = canvas.width / 2
    xMargin = Math.floor((canvas.width / size) / 4) * size

    if ((canvas.height / size) % 2 === 0) {
        middleY = canvas.height / 2
    } else {
        middleY = (canvas.height / 2) - size / 2
    }

    randomXPos = () => {
        let maxMultipleX = Math.floor(canvas.width / size)
        let randomMultipleX = Math.floor(Math.random() * (maxMultipleX + 1));
        let result = (randomMultipleX * size) - size
        if (result < 0){ result = 0 }
        return result
    }
    
    randomYPos = () => {
        let maxMultipleY = Math.floor(canvas.height / size)
        let randomMultipleY = Math.floor(Math.random() * (maxMultipleY + 1));
        let result = (randomMultipleY * size) - size
        if (result < 0){ result = 0 }
        return result
    }

    snake = [
        {x: xMargin, y: middleY},
        {x: xMargin + (size), y: middleY},
        {x: xMargin + (size * 2), y: middleY},
        {x: xMargin + (size * 3), y: middleY},
    ]
    
    fruit = {x: canvas.width - xMargin, y: middleY}
}

function changeDirection(e){
    if (db) return

        if ((e.key === 'w' || e.key === 'ArrowUp') && direction !== 'down') {
            direction = 'up'
            db = true
        }
        else if ((e.key === 's' || e.key === 'ArrowDown') && direction !== 'up') {
            direction = 'down'
            db = true
        }
        else if ((e.key === 'a' || e.key === 'ArrowLeft') && direction !== 'right' && direction) {
            direction = 'left'
            db = true
        }
        else if ((e.key === 'd' || e.key === 'ArrowRight') && direction !== 'left') {
            direction = 'right'
            db = true
        }
}

playButton.addEventListener('click', () => {
    eaten = 0
    document.addEventListener('keydown', changeDirection)
    updateLayoutVars()
})

function drawRotatedImage(img, x, y, size, angleDeg) {
    const angleRad = angleDeg * Math.PI / 180;

    ctx.save();
    ctx.translate(x + size / 2, y + size / 2);
    ctx.rotate(angleRad);
    ctx.drawImage(img, -size / 2, -size / 2, size, size);
    ctx.restore();
}

let drawSnake = () => {
    let mainColor = color
    for (let i = snake.length - 1; i >= 0; i--) {
        let pos = snake[i]
        ctx.fillStyle = color
        
        if (i === snake.length - 1) {
            ctx.fillRect(pos.x, pos.y, size, size)

            if (currentDirection == 'right' || currentDirection == 'left'){
                drawRotatedImage(eyeImage, pos.x, pos.y, size, 90)
            }else{
                ctx.drawImage(eyeImage, pos.x, pos.y, size, size) 
            }
            
        }
        else {
            ctx.fillRect(pos.x, pos.y, size, size)
        }

        let [r, g, b] = color.match(/\d+/g).map(Number)

        if (r > 50 || g > 50 || b > 50){
            color = `rgb(${r - colorGradient}, ${g - colorGradient}, ${b - colorGradient})`
        }
    }
    color = mainColor
}

let drawFruit = () => {
    ctx.shadowColor = 'white'
    ctx.shadowBlur = 20
    ctx.drawImage(fruitImage, fruit.x, fruit.y, size, size)
    ctx.shadowBlur = 0
}

let checkEat = () => {
    if (eaten + 4 < rows * columns){
        const head = snake[snake.length - 1]
        
        if (head.x === fruit.x && head.y === fruit.y) {      
            shouldGrow = true;

            eaten++
            let x = randomXPos()
            let y = randomYPos()

            while (snake.find((pos) => pos.x === x && pos.y === y)){
                x = randomXPos()
                y = randomYPos()
            }

            fruit.x = x
            fruit.y = y
            
            document.querySelector('.background-game').querySelector('.fruit-counter').innerText = eaten

            if (eaten >= record){
                record = eaten
                document.querySelector('.background-game').querySelector('.trophy-counter').innerText = record
            }
        }
    }
}

let gameOver = (str) => {
    direction = undefined
    currentDirection = undefined
    document.removeEventListener('keydown', changeDirection)
    gameOverMenu.style.display = 'flex'
    gameOverMenu.querySelector('.background').querySelector('h1').textContent = str
    gameOverMenu.querySelector('h2').innerText = `frutas comidas: ${eaten}`
    canvas.style.filter = 'blur(5px)'
}

let checkRestart = () => {
    console.log(snake.length)
    if (snake.length === (rows * columns)){
        gameOver('Parabéns, você completou todo o tabuleiro! 👏👏👏')
    }
}

let checkCollision = () => {
    let head = snake[snake.length - 1]
    let neck = snake.length - 2

    const wallColision = head.x < 0 || head.x >= canvas.width || head.y < 0 || head.y >= canvas.height
    const selfColision = snake.find((pos, i) => {
        return i < neck && pos.x === head.x && pos.y === head.y
    })
    
    if (wallColision || selfColision) {
        gameOver('Você Perdeu! 🤦‍♂️🤷‍♂️')
    }
}

let moveSnake = () => {
    if (!direction) return
    let head = snake[snake.length - 1]
    let oldPos = {x: head.x, y: head.y}

    if (head.x % size === 0 && head.y % size === 0) {
        currentDirection = direction;
        db = false
    }

    switch (currentDirection) {
        case 'up':
            head.y -= size
            break
        case 'down':
            head.y += size
            break
        case 'left':
            head.x -= size
            break
        case 'right':
            head.x += size
            break
    }

    for (let i = snake.length - 2; i >= 0; i--){
       let temp = snake[i]
        snake[i] = oldPos
        oldPos = temp 
    }

    if (shouldGrow){
        snake.unshift(oldPos)
        shouldGrow = false
    }
}

let drawLine = () => {
    ctx.lineWidth = 1
    ctx.strokeStyle = strokeColor

    for (let i = size; i < canvas.width; i += size) {
        ctx.beginPath()
        ctx.lineTo(i, 0)
        ctx.lineTo(i, canvas.height)
        ctx.stroke()
    }

    for(let i = size; i < canvas.height; i += size) {
        ctx.beginPath()
        ctx.lineTo(0, i)
        ctx.lineTo(canvas.width, i)
        ctx.stroke()
    }

}

let gameLoop = () => {
    clearInterval(loop)
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    checkRestart()
    drawLine()
    moveSnake()
    drawSnake()
    drawFruit()
    checkEat() 
    checkCollision()

    loop = setInterval(() => {
        gameLoop()
    }, 500 - speed * 30)
}

let restart = () => {
    eaten = 0
    document.querySelector('.background-game').querySelector('.fruit-counter').innerText = eaten
    gameOverMenu.style.display = 'none'
    canvas.style.filter = 'none'
    direction = undefined
    updateLayoutVars()
    snake = [
    {x: xMargin, y: middleY},
    {x: xMargin + (size), y: middleY},
    {x: xMargin + (size * 2), y: middleY},
    {x: xMargin + (size * 3), y: middleY},
    ]
    fruit = {x: canvas.width - xMargin, y: middleY}
}

restartButton.addEventListener('click', () => {
    restart()
    document.addEventListener('keydown', changeDirection)
})

menuButton.addEventListener('click', () => {
    restart()
    gameMenu.style.display = 'none'
    mainMenu.style.display = 'flex'
})

gameLoop()