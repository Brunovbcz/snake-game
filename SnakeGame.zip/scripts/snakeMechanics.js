let canvas = document.querySelector('canvas')
let ctx = canvas.getContext('2d')

let gameOverMenu = document.querySelector('.game-over-menu')
let fruitImg = document.querySelector('.fruit-img')

const restartButton = document.querySelector('#restart')
const menuButton = document.querySelector('#menu')

let realcolors = {
    red:     [190, 30, 45],
    blue:    [60, 100, 180],
    green:   [60, 120, 60],
    yellow:  [240, 220, 100],
    orange:  [230, 120, 40],
    purple:  [100, 70, 130],
    black:   [20, 20, 20],
    white:   [245, 245, 245],
    gray:    [110, 110, 110],
    pink:    [230, 150, 170],
}

const size = 30
const colorGradient = 1
let speed = 4
let eaten = 0
let record = 0

let middleX = canvas.width / 2
let middleY

if ((canvas.height / size) % 2 === 0) { middleY = canvas.height / 2 }
else { middleY = (canvas.height / 2) - size / 2 }

let xMargin = Math.floor((canvas.width / size) / 4) * size

let direction
let currentDirection
let color = 'rgb(60, 100, 180)'
let strokeColor = 'gray'
let loop
let db = false

const eyeImage = new Image()
eyeImage.src = 'contents/images/snake/eyes/graphics_00.png'

const fruitImage = new Image()
fruitImage.src = 'contents/images/fruits/apple.png'
fruitImg.src = fruitImage.src

let randomXPos = () => {
    return Math.round(Math.random() * (canvas.width - size) / size) * size
}

let randomYPos = () => {
    return Math.round(Math.random() * (canvas.height - size) / size) * size
}

let snake = [
    {x: xMargin, y: middleY},
    {x: xMargin + 30, y: middleY},
    {x: xMargin + 60, y: middleY},
    {x: xMargin + 90, y: middleY},
]

let fruit = {x: canvas.width - xMargin, y: middleY}

function changeDirection(e){
    if (db) return

        if ((e.key === 'w' || e.key === 'ArrowUp') && direction !== 'down') {
            direction = 'up'
            db = true
        }
        else if ((e.key === 's' || e.key === 'ArrowDown') && direction !== 'up') {
            direction = 'down'
            db = true
        }
        else if ((e.key === 'a' || e.key === 'ArrowLeft') && direction !== 'right' && direction) {
            direction = 'left'
            db = true
        }
        else if ((e.key === 'd' || e.key === 'ArrowRight') && direction !== 'left') {
            direction = 'right'
            db = true
        }
}

playButton.addEventListener('click', () => {
    eaten = 0
    document.addEventListener('keydown', changeDirection)
})

let drawSnake = () => {
    let mainColor = color
    for (let i = snake.length - 1; i >= 0; i--) {
        let pos = snake[i]
        ctx.fillStyle = color
        
        if (i === snake.length - 1) {
            ctx.fillRect(pos.x, pos.y, size, size)
            ctx.drawImage(eyeImage, pos.x, pos.y, size, size)
        }
        else {
            ctx.fillRect(pos.x, pos.y, size, size)
        }

        let [r, g, b] = color.match(/\d+/g).map(Number)

        if (r > 50 || g > 50 || b > 50){
            color = `rgb(${r - colorGradient}, ${g - colorGradient}, ${b - colorGradient})`
        }
    }
    color = mainColor
}

let drawFruit = () => {
    ctx.shadowColor = 'white'
    ctx.shadowBlur = 20
    ctx.drawImage(fruitImage, fruit.x, fruit.y, size, size)
    ctx.shadowBlur = 0
}

let checkEat = () => {
    const head = snake[snake.length - 1]

    if (head.x === fruit.x && head.y === fruit.y) {      
        snake.push({x: head.x, y: head.y})

        let x = randomXPos()
        let y = randomYPos()

        while (snake.find((pos) => pos.x === x && pos.y === y)){
            x = randomXPos()
            y = randomYPos()
        }

        fruit.x = x
        fruit.y = y
        eaten++
        document.querySelector('.background-game').querySelector('.fruit-counter').innerText = eaten

        if (eaten >= record){
            record = eaten
            document.querySelector('.background-game').querySelector('.trophy-counter').innerText = record
        }
    }
}

let gameOver = () => {
    direction = undefined
    currentDirection = undefined
    document.removeEventListener('keydown', changeDirection)
    gameOverMenu.style.display = 'flex'
    gameOverMenu.querySelector('h2').innerText = `frutas comidas: ${eaten}`
    canvas.style.filter = 'blur(5px)'
}

let checkCollision = () => {
    let head = snake[snake.length - 1]
    let neck = snake.length - 2

    const wallColision = head.x < 0 || head.x >= canvas.width || head.y < 0 || head.y >= canvas.height
    const selfColision = snake.find((pos, i) => {
        return i < neck && pos.x === head.x && pos.y === head.y
    })
    
    if (wallColision || selfColision) {
        gameOver()
    }
}

let moveSnake = () => {
    if (!direction) return
    let head = snake[snake.length - 1]
    let oldPos = {x: head.x, y: head.y}

    if (head.x % size === 0 && head.y % size === 0) {
        currentDirection = direction;
        db = false
    }

    switch (currentDirection) {
        case 'up':
            head.y -= size
            break
        case 'down':
            head.y += size
            break
        case 'left':
            head.x -= size
            break
        case 'right':
            head.x += size
            break
    }

    for (let i = snake.length - 2; i >= 0; i--){
       let temp = snake[i]
        snake[i] = oldPos
        oldPos = temp 
    }
}

let drawLine = () => {
    ctx.lineWidth = 1
    ctx.strokeStyle = strokeColor

    for (let i = size; i < canvas.width; i += size) {
        ctx.beginPath()
        ctx.lineTo(i, 0)
        ctx.lineTo(i, canvas.height)
        ctx.stroke()
    }

    for(let i = size; i < canvas.height; i += size) {
        ctx.beginPath()
        ctx.lineTo(0, i)
        ctx.lineTo(canvas.width, i)
        ctx.stroke()
    }

}

let gameLoop = () => {
    clearInterval(loop)
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    drawLine()
    moveSnake()
    drawSnake()
    drawFruit()
    checkEat() 
    checkCollision()

    loop = setInterval(() => {
        gameLoop()
    }, 500 / speed)
}

let restart = () => {
    eaten = 0
    document.querySelector('.background-game').querySelector('.fruit-counter').innerText = eaten
    gameOverMenu.style.display = 'none'
    canvas.style.filter = 'none'
    direction = undefined
    snake = [
    {x: xMargin, y: middleY},
    {x: xMargin + 30, y: middleY},
    {x: xMargin + 60, y: middleY},
    {x: xMargin + 90, y: middleY},
    ]
    fruit = {x: canvas.width - xMargin, y: middleY}
}

restartButton.addEventListener('click', () => {
    restart()
    document.addEventListener('keydown', changeDirection)
})

menuButton.addEventListener('click', () => {
    restart()
    gameMenu.style.display = 'none'
    mainMenu.style.display = 'flex'
})

gameLoop()