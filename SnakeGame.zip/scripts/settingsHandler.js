let gridButton = document.querySelector('#grid')
let gameOptionsButton = document.querySelector('#game-options')
let soundButton = document.querySelector('#sound')
let screenButton = document.querySelector('#screen')

// Settings menu
let gridSettings = document.querySelector('.grid-settings')
let gameOptions = document.querySelector('.game-options')

gridButton.addEventListener('click', () => {
    gameOptions.style.display = 'none'
    gridSettings.style.display = 'flex'
})

gameOptionsButton.addEventListener('click', () => {
    gridSettings.style.display = 'none'
    gameOptions.style.display = 'flex'
})

soundButton.addEventListener('click', () => {
    
})

screenButton.addEventListener('click', () => {
    
})