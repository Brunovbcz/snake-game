//Menus
let fruitMenu = document.querySelector('.fruits-menu')
let eyesMenu = document.querySelector('.eyes-menu')
let colorsMenu = document.querySelector('.colors-menu')
let themeMenu = document.querySelector('.theme-menu')

//Buttons
let fruitsButton = document.querySelector('#fruits-button')
let eyesButton = document.querySelector('#eyes-button')
let colorsButton = document.querySelector('#colors-button')
let themeButton = document.querySelector('#theme-button')
let randomButton = document.querySelector('#random-button')

//Intialized variables
let color = 'rgb(60, 100, 180)'

let changeMenus = (menu) => {
    fruitMenu.style.display = 'none'
    eyesMenu.style.display = 'none'
    colorsMenu.style.display = 'none'
    themeMenu.style.display = 'none'

    menu.style.display = 'flex'
}

let drawCustomizeSnake = () =>{
    let canvas = document.querySelector('.snake-canvas')
    let ctx = canvas.getContext('2d')

    canvas.height = 100
    canvas.width = 400

    ctx.fillStyle = color   
    
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(eyeImage, 300, 0, 95, 95)
}

fruitsButton.addEventListener('click', () => {
    changeMenus(fruitMenu)

    let left = fruitMenu.querySelector('#l-fruits')
    let right = fruitMenu.querySelector('#r-fruits')
    let fruitCounter = 0
    let fruitMenuImage = document.querySelector('.fruit-menu-img')

    let fruits = [
        apple = 'contents/images/fruits/apple.png',
        banana = 'contents/images/fruits/banana.png',
        grape = 'contents/images/fruits/grape.png',
        kiwi = 'contents/images/fruits/kiwi.png',
        melon = 'contents/images/fruits/melon.png',
        orange = 'contents/images/fruits/orange.png',
        pear = 'contents/images/fruits/pear.png',
        pineapple = 'contents/images/fruits/pineapple.png',
        strawberry = 'contents/images/fruits/strawberry.png',
        watermelon = 'contents/images/fruits/watermelon.png'
    ]

    right.addEventListener('click', () => {
        fruitCounter ++
        if (fruitCounter > fruits.length - 1){
            fruitCounter = 0
        }
        
        fruitImage.src = fruits[fruitCounter]
        fruitMenuImage.src = fruits[fruitCounter]
        fruitImg .src = fruits[fruitCounter]
    })

    left.addEventListener('click', () => {
        fruitCounter --
        
        if (fruitCounter < 0){
            fruitCounter = fruits.length - 1
        }
        fruitImage.src = fruits[fruitCounter]
        fruitMenuImage.src = fruits[fruitCounter]
        fruitImg.src = fruits[fruitCounter]
    })
})

eyesButton.addEventListener('click', () => {
    changeMenus(eyesMenu)

    let left = eyesMenu.querySelector('#l-eyes')
    let right = eyesMenu.querySelector('#r-eyes')
    let eyesCounter = 0
    let eyeMenuImage = document.querySelector('.eye-menu-img')

    let eyes = [
        var1 = 'contents/images/snake/eyes/var1.png',
        var2 = 'contents/images/snake/eyes/var2.png',
        var3 = 'contents/images/snake/eyes/var3.png',
        var4 = 'contents/images/snake/eyes/var4.png',
        var5 = 'contents/images/snake/eyes/var5.png',
        var6 = 'contents/images/snake/eyes/var6.png',
        var7 = 'contents/images/snake/eyes/var7.png',
        var8 = 'contents/images/snake/eyes/var8.png'
    ]

    right.addEventListener('click', () => {
        eyesCounter ++
        if (eyesCounter > eyes.length - 1){
            eyesCounter = 0
        }

        eyeImage.src = eyes[eyesCounter]
        eyeMenuImage.src = eyes[eyesCounter]
    })

    left.addEventListener('click', () => {
        eyesCounter --
        if (eyesCounter < 0){
            eyesCounter = eyes.length - 1
        }

        eyeImage.src = eyes[eyesCounter]
        eyeMenuImage.src = eyes[eyesCounter]
    })
})

colorsButton.addEventListener('click', () => {
    changeMenus(colorsMenu)
    drawCustomizeSnake()

    let left = colorsMenu.querySelector('#l-colors')
    let right = colorsMenu.querySelector('#r-colors')
    let colorsCounter = 0

    let canvas = document.querySelector('.snake-canvas')
    let ctx = canvas.getContext('2d')
    
    let colors = [
        blue = 'rgb(60, 100, 180)',
        red = 'rgb(190, 30, 45)',
        green = 'rgb(60, 120, 60)',
        yellow = 'rgb(240, 220, 100)',
        orange = 'rgb(230, 120, 40)',
        purple = 'rgb(100, 70, 130)',
        black = 'rgb(20, 20, 20)',
        white = 'rgb(245, 245, 245)',
        gray = 'rgb(110, 110, 110)',
        pink = 'rgb(230, 150, 170)'
    ]
    
    right.addEventListener('click', () => {
        colorsCounter ++
        if (colorsCounter > colors.length - 1){
            colorsCounter = 0
        }

        ctx.clearRect(0, 0, canvas.width, canvas.height)
        color = colors[colorsCounter]
        drawCustomizeSnake()
    })

    left.addEventListener('click', () => {
        colorsCounter --
        if (colorsCounter < 0){
            colorsCounter = colors.length - 1
        }

        ctx.clearRect(0, 0, canvas.width, canvas.height)
        color = colors[colorsCounter]
        drawCustomizeSnake(colors[colorsCounter])
    })
})

themeButton.addEventListener('click', () => {
    changeMenus(themeMenu)
})

randomButton.addEventListener('click', () => {
    
})