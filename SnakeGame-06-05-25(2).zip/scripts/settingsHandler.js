let gridButton = document.querySelector('#grid')
let gameOptionsButton = document.querySelector('#game-options')
let soundButton = document.querySelector('#sound')
let screenButton = document.querySelector('#screen')

// Settings menu
let gridSettings = document.querySelector('.grid-settings')
let gameOptions = document.querySelector('.game-options')

//Global variables
let rows = 11
let columns = 14

//elements
let nh1 = document.querySelector('.nh1')

//Canvas Preview
let canvasPreview = () => {
    let canvas = document.querySelector('.grid-canvas')
    let ctx = canvas.getContext('2d')
    let size = 28

    canvas.width = columns * size
    canvas.height = rows * size

    let drawLine = () => {
        ctx.lineWidth = 1
        ctx.strokeStyle = 'gray'

        for (let i = size; i < canvas.width; i += size) {
            ctx.beginPath()
            ctx.lineTo(i, 0)
            ctx.lineTo(i, canvas.height)
            ctx.stroke()
        }
        
        for(let i = size; i < canvas.height; i += size) {
            ctx.beginPath()
            ctx.lineTo(0, i)
            ctx.lineTo(canvas.width, i)
            ctx.stroke()
        }
    }
    drawLine()
}
canvasPreview()

let verifyPair = () => {
    if (!(rows * columns % 2 === 0)){
        nh1.style.marginTop = '5.8%'
        nh1.style.display = ''
        nh1.style.color = 'rgb(235, 228, 16)'
        gridSettings.style.flexDirection = 'column'
    }
    else{
        nh1.style.display = 'none'
        gridSettings.style.flexDirection = 'row'
    }
}

gridButton.addEventListener('click', () => {
    gameOptions.style.display = 'none'
    gridSettings.style.display = 'flex'

    let lSlider = document.querySelector('#l-slider')
    let lSliderValue = document.querySelector('#l-slider-value')

    let rSlider = document.querySelector('#r-slider')
    let rSliderValue = document.querySelector('#r-slider-value')
    
    lSlider.addEventListener('input', () => {
        lSliderValue.textContent = lSlider.value
        columns = lSlider.value
        canvasPreview()
        verifyPair()
    })

    rSlider.addEventListener('input', () => {
        rSliderValue.textContent = rSlider.value
        rows = rSlider.value
        canvasPreview()
        verifyPair()
    })
})

gameOptionsButton.addEventListener('click', () => {
    gridSettings.style.display = 'none'
    gameOptions.style.display = 'flex'

    let sSlider = document.querySelector('#s-slider')
    let sSliderValue = document.querySelector('#s-slider-value')

    sSlider.addEventListener('input', () => {
        sSliderValue.textContent = sSlider.value
        speed = sSlider.value
    })
})

soundButton.addEventListener('click', () => {
    
})

screenButton.addEventListener('click', () => {
    
})